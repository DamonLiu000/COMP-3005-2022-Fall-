package com.book.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.book.common.ResultObject;
import com.book.service.OrderService;

/**
 * 
 * @author
 * @since
 */
@RestController
@RequestMapping("/order")
public class OrderController {

	@Autowired
    OrderService orderService;
	
	
	
	@GetMapping("/queryListLevel")
    public ResultObject queryListLevel(String arrears_date){
    	
		Map<String, Object> result = orderService.queryListLevel(arrears_date);
    	return ResultObject.isOk(result); 
    }
	
	/**
	 * 
	 * @param params
	 * @return
	 */
    @GetMapping("/queryMate")
    public ResultObject queryMate(String id,String user_id){
    	
    	orderService.queryMate(id,user_id);
    	return ResultObject.isOk(); 
    }
	
	/**
	 * add
	 * @param params
	 * @return
	 */
    @PostMapping("/add")
    public ResultObject add(@RequestBody Map<String, Object> params){
    	orderService.add(params);
    	return ResultObject.isOk(); 
    }


	/**
	 * update
	 * @param params
	 * @return
	 */
    @PostMapping("/update")
    public ResultObject update(@RequestBody Map<String, Object> params){
    	orderService.update(params);
    	return ResultObject.isOk();  
    }


	
	/**
	 * delete
	 * @param id
	 * @return
	 */
	@GetMapping("/delete")
    public ResultObject delete(String id){
    	orderService.delete(id);
    	return ResultObject.isOk();  
    }


	/**
	 * Query paging data
	 * @param params
	 * @return
	 */
	@PostMapping("queryList")
	public ResultObject queryList(@RequestBody Map<String, Object> params){
		Map<String, Object> result = orderService.queryList(params);
		return ResultObject.isOk(result.get("list"),Integer.valueOf(result.get("count").toString()));
	}

	
	/**
	 * ID query
	 * @param id
	 * @return
	 */
    @GetMapping("/queryDetail")
    public ResultObject queryDetail(String id){
    	Map<String, Object> result = orderService.queryDetail(id);
    	return ResultObject.isOk(result); 
    }
	
}
