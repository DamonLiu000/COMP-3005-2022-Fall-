package com.book.service.impl;

import com.book.mapper.SaleMapper;
import com.book.service.SaleService;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author
 * @since
 */
@Service
public class SaleServiceImpl implements SaleService {

	@Autowired
    SaleMapper saleMapper;
 
    /**
	 * add
	 * @param params
	 * @return
	 */
    public void add(Map<String, Object> params) {
    	params.put("id", System.currentTimeMillis());
		saleMapper.add(params);
	}
 

	/**
	 * Query paging data
	 * @param params
	 * @return
	 */
    public Map<String, Object> queryList(Map<String, Object> params) {
		params.put("page",
				(Integer.valueOf(params.get("page").toString()) - 1) * Integer.valueOf(params.get("limit").toString()));
		List<Map<String, Object>> list = saleMapper.queryList(params);
		int count = saleMapper.queryCount(params);
		params = new HashMap<String, Object>();
		params.put("list", list);
		params.put("count", count);
		return params;
	}
	

	/**
	 * ID query
	 * @param id
	 * @return
	 */
	public Map<String, Object> queryDetail(String id) {
		
		Map<String, Object> result = saleMapper.queryDetail(id);
		return result;
	}

	/**
	 * update
	 * @param params
	 * @return
	 */
	public void update(Map<String, Object> params) {
		 
		saleMapper.update(params);
	}

	/**
	 * delete
	 * @param id
	 * @return
	 */
	public void delete(String id) {
		 
		saleMapper.delete(id);
	}

}
