package com.book.service.impl;

import com.book.mapper.OrderMapper;
import com.book.mapper.TransportMapper;
import com.book.service.TransportService;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author
 * @since
 */
@Service
public class TransportServiceImpl implements TransportService {

	@Autowired
    TransportMapper transportMapper;
	
	@Autowired
	OrderMapper orderMapper;
 
    /**
	 * add
	 * @param params
	 * @return
	 */
    public void add(Map<String, Object> params) {
    	params.put("id", System.currentTimeMillis());
		transportMapper.add(params);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", params.get("order_no"));
		map.put("state", 2);
		orderMapper.update(map);
		
	}
 

	/**
	 * Query paging data
	 * @param params
	 * @return
	 */
    public Map<String, Object> queryList(Map<String, Object> params) {
		params.put("page",
				(Integer.valueOf(params.get("page").toString()) - 1) * Integer.valueOf(params.get("limit").toString()));
		List<Map<String, Object>> list = transportMapper.queryList(params);
		int count = transportMapper.queryCount(params);
		params = new HashMap<String, Object>();
		params.put("list", list);
		params.put("count", count);
		return params;
	}
	

	/**
	 * ID query
	 * @param id
	 * @return
	 */
	public Map<String, Object> queryDetail(String id) {
		
		Map<String, Object> result = transportMapper.queryDetail(id);
		return result;
	}

	/**
	 * update
	 * @param params
	 * @return
	 */
	public void update(Map<String, Object> params) {
		 
		transportMapper.update(params);
	}

	/**
	 * delete
	 * @param id
	 * @return
	 */
	public void delete(String id) {
		 
		transportMapper.delete(id);
	}

}
