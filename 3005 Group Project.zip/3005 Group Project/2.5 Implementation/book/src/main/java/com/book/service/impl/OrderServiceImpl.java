package com.book.service.impl;

import com.book.mapper.BookMapper;
import com.book.mapper.CheckoutBasketMapper;
import com.book.mapper.OrderDetailsMapper;
import com.book.mapper.OrderMapper;
import com.book.mapper.PublishersMapper;
import com.book.mapper.SaleMapper;
import com.book.service.BookService;
import com.book.service.CheckoutBasketService;
import com.book.service.OrderService;
import com.book.service.PublishersService;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author
 * @since
 */
@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
    OrderMapper orderMapper;
	
	@Autowired
	BookMapper bookMapper;
	
	@Autowired
	OrderDetailsMapper orderDetailsMapper;
	
	@Autowired
	CheckoutBasketMapper checkoutBasketMapper;
	
	@Autowired
	PublishersMapper publishersMapper;
	
	@Autowired
	SaleMapper saleMapper;
 
    /**
	 * add
	 * @param params
	 * @return
	 */
    public void add(Map<String, Object> params) {
    	params.put("id", System.currentTimeMillis());
		orderMapper.add(params);
	}
 

	/**
	 * Query paging data
	 * @param params
	 * @return
	 */
    public Map<String, Object> queryList(Map<String, Object> params) {
		params.put("page",
				(Integer.valueOf(params.get("page").toString()) - 1) * Integer.valueOf(params.get("limit").toString()));
		List<Map<String, Object>> list = orderMapper.queryList(params);
		int count = orderMapper.queryCount(params);
		params = new HashMap<String, Object>();
		params.put("list", list);
		params.put("count", count);
		return params;
	}
	

	/**
	 * ID query
	 * @param id
	 * @return
	 */
	public Map<String, Object> queryDetail(String id) {
		
		Map<String, Object> result = orderMapper.queryDetail(id);
		return result;
	}

	/**
	 * update
	 * @param params
	 * @return
	 */
	public void update(Map<String, Object> params) {
		 
		orderMapper.update(params);
	}

	/**
	 * delete
	 * @param id
	 * @return
	 */
	public void delete(String id) {
		 
		orderMapper.delete(id);
	}


	public void queryMate(String id,String user_id) {
		 String [] str = id.split(",");
		 List<Map<String, Object>> checkout = checkoutBasketMapper.queryListById(user_id);
		 List<Map<String, Object>> list = bookMapper.queryListById(str);
		 List<String> bookstore = new ArrayList<String>();
		 List<String> publishers = new ArrayList<String>();
		 for (Map<String, Object> map : list) {
			 if(bookstore.size()<1){
				 bookstore.add(map.get("bookstore_id").toString());
			 }
			 for (String bookstore_id : bookstore) {
					 if(!bookstore_id.equals(map.get("bookstore_id").toString())){
							bookstore.add(map.get("bookstore_id").toString());
					}
			}
			 if(publishers.size()<1){
				 publishers.add(map.get("publisher_id").toString());
			 }
			 for (String publishers_id : publishers) {
				 if(!publishers_id.equals(map.get("publisher_id").toString())){
					 publishers.add(map.get("publisher_id").toString());
				}
		}
			 
		 }
		 
		 for (Map<String, Object> map : checkout) {
			 for (Map<String, Object> map1 : list) {
				  if(map.get("book_id").toString().equals(map1.get("id").toString())){
					  map1.put("num", map.get("num"));
					  map1.put("price", Integer.valueOf(map.get("num").toString())*
							  Double.valueOf(map1.get("price").toString()));
				  }
			 } 
		 }
		 
		 
		 for (String bookstoreID : bookstore) {
			 Map<String, Object> params = new HashMap<String, Object>();
			 params.put("id", System.currentTimeMillis());
			 params.put("order_no", System.currentTimeMillis());
			 params.put("bookstore_id", bookstoreID);
			 params.put("user_id", user_id);
			 params.put("create_time", new Date());
			 params.put("state", 1);
			 Double d =0.00;
			 for (Map<String, Object> map : list) {
				 if(bookstoreID.equals(map.get("bookstore_id").toString())){
					 d+=Double.valueOf(map.get("price").toString());
					 params.put("total_price", d);
				 }
			}
			 orderMapper.add(params);
			for (Map<String, Object> map : list) {
				Map<String, Object> orderDetail = new HashMap<String, Object>();
				 if(bookstoreID.equals(map.get("bookstore_id").toString())){
					 orderDetail.put("id", System.currentTimeMillis());
					 orderDetail.put("order_id", params.get("id"));
					 orderDetail.put("book_id", map.get("id"));
					 orderDetail.put("quantity", map.get("num"));
					 orderDetail.put("price", map.get("price"));
					 orderDetailsMapper.add(orderDetail);
				 }
			}
			
			List<Map<String, Object>> publishers_list = publishersMapper.queryListById(publishers);
			for (Map<String, Object> map : publishers_list) {
				Map<String, Object> sale = new HashMap<String, Object>();
				if(bookstoreID.equals(map.get("bookstore_id").toString())){
					sale.put("publishers_id", map.get("id"));
					sale.put("banking_account", map.get("banking_account"));
					sale.put("order_id", bookstoreID);
					Double d1 =0.00;
					for (Map<String, Object> map1 : list) {
						 if(map.get("id").toString().equals(map1.get("publisher_id").toString())){
							 d1+=Double.valueOf(map1.get("price").toString());
							 sale.put("sales_volume", d1);
						 }
					}
				 }
				sale.put("id", System.currentTimeMillis());
				saleMapper.add(sale);
			}
		}
		 checkoutBasketMapper.deleteUserId(user_id);
		 
	}


	public Map<String, Object> queryListLevel(String arrears_date) {
		List<Map<String, Object>> result = orderMapper.queryListLevel(arrears_date);
		List<String> index_values = new ArrayList<String>();
		List<String> values = new ArrayList<String>();
		for (Map<String, Object> map: result) {
			index_values.add(map.get("month").toString());
			values.add(map.get("total_price").toString());
		}
		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("index", index_values);
		map.put("values", values);
		return map;
	}

}
