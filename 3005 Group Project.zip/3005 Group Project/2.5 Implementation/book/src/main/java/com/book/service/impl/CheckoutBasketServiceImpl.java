package com.book.service.impl;

import com.book.mapper.CheckoutBasketMapper;
import com.book.service.CheckoutBasketService;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author
 * @since
 */
@Service
public class CheckoutBasketServiceImpl implements CheckoutBasketService {

	@Autowired
    CheckoutBasketMapper checkoutBasketMapper;
 
    /**
	 * add
	 * @param params
	 * @return
	 */
    public void add(Map<String, Object> params) {
    	params.put("id", System.currentTimeMillis());
    	params.put("create_time", new Date());
		checkoutBasketMapper.add(params);
	}
 

	/**
	 * Query paging data
	 * @param params
	 * @return
	 */
    public Map<String, Object> queryList(Map<String, Object> params) {
		params.put("page",
				(Integer.valueOf(params.get("page").toString()) - 1) * Integer.valueOf(params.get("limit").toString()));
		List<Map<String, Object>> list = checkoutBasketMapper.queryList(params);
		int count = checkoutBasketMapper.queryCount(params);
		params = new HashMap<String, Object>();
		params.put("list", list);
		params.put("count", count);
		return params;
	}
	

	/**
	 * ID query
	 * @param id
	 * @return
	 */
	public Map<String, Object> queryDetail(String id) {
		
		Map<String, Object> result = checkoutBasketMapper.queryDetail(id);
		return result;
	}

	/**
	 * update
	 * @param params
	 * @return
	 */
	public void update(Map<String, Object> params) {
		 
		checkoutBasketMapper.update(params);
	}

	/**
	 * delete
	 * @param id
	 * @return
	 */
	public void delete(String id) {
		 
		checkoutBasketMapper.delete(id);
	}

}
