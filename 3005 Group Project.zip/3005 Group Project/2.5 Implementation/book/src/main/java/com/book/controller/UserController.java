package com.book.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.book.common.ResultObject;
import com.book.service.UserService;

/**
 * 
 * @author
 * @since
 */
@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
    UserService userService;
	
	
	/**
	 * login
	 * @param params
	 * @return
	 */
    @PostMapping("/login")
    public ResultObject login(@RequestBody Map<String, Object> params){
    	
    	if("admin".equals(params.get("no"))){
    		params.put("type", 1);
    		return ResultObject.isOk(params); 
    	}
    	
    	Map<String, Object> result = userService.loginAdmin(params);
    	if(result != null){
    		result.put("type", 2);
    		return ResultObject.isOk(result); 
    	}
    	result = userService.loginUser(params);
    	if(result != null){
    		result.put("type", 3);
    		return ResultObject.isOk(result); 
    	}
    	return ResultObject.ErrorMsg("user does not exist"); 
    }


	/**
	 * add
	 * @param params
	 * @return
	 */
    @PostMapping("/add")
    public ResultObject add(@RequestBody Map<String, Object> params){
    	userService.add(params);
    	return ResultObject.isOk(); 
    }


	/**
	 * update
	 * @param params
	 * @return
	 */
    @PostMapping("/update")
    public ResultObject update(@RequestBody Map<String, Object> params){
    	userService.update(params);
    	return ResultObject.isOk();  
    }


	
	/**
	 * delete
	 * @param id
	 * @return
	 */
	@GetMapping("/delete")
    public ResultObject delete(String id){
    	userService.delete(id);
    	return ResultObject.isOk();  
    }


	/**
	 * Query paging data
	 * @param params
	 * @return
	 */
	@PostMapping("queryList")
	public ResultObject queryList(@RequestBody Map<String, Object> params){
		Map<String, Object> result = userService.queryList(params);
		return ResultObject.isOk(result.get("list"),Integer.valueOf(result.get("count").toString()));
	}

	
	/**
	 * ID query
	 * @param id
	 * @return
	 */
    @GetMapping("/queryDetail")
    public ResultObject queryDetail(String id){
    	Map<String, Object> result = userService.queryDetail(id);
    	return ResultObject.isOk(result); 
    }
	
}
