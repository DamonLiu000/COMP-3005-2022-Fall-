package com.book.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.book.common.ResultObject;
import com.book.service.OrderDetailsService;

/**
 * 
 * @author
 * @since
 */
@RestController
@RequestMapping("/order/details")
public class OrderDetailsController {

	@Autowired
    OrderDetailsService orderDetailsService;


	/**
	 * add
	 * @param params
	 * @return
	 */
    @PostMapping("/add")
    public ResultObject add(@RequestBody Map<String, Object> params){
    	orderDetailsService.add(params);
    	return ResultObject.isOk(); 
    }


	/**
	 * update
	 * @param params
	 * @return
	 */
    @PostMapping("/update")
    public ResultObject update(@RequestBody Map<String, Object> params){
    	orderDetailsService.update(params);
    	return ResultObject.isOk();  
    }


	
	/**
	 * delete
	 * @param id
	 * @return
	 */
	@GetMapping("/delete")
    public ResultObject delete(String id){
    	orderDetailsService.delete(id);
    	return ResultObject.isOk();  
    }


	/**
	 * Query paging data
	 * @param params
	 * @return
	 */
	@PostMapping("queryList")
	public ResultObject queryList(@RequestBody Map<String, Object> params){
		Map<String, Object> result = orderDetailsService.queryList(params);
		return ResultObject.isOk(result.get("list"),Integer.valueOf(result.get("count").toString()));
	}

	
	/**
	 * ID query
	 * @param id
	 * @return
	 */
    @GetMapping("/queryDetail")
    public ResultObject queryDetail(String id){
    	Map<String, Object> result = orderDetailsService.queryDetail(id);
    	return ResultObject.isOk(result); 
    }
	
}
