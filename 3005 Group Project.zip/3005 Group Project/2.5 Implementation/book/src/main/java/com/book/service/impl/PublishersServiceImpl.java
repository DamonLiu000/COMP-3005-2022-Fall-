package com.book.service.impl;

import com.book.mapper.PublishersMapper;
import com.book.service.PublishersService;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author
 * @since
 */
@Service
public class PublishersServiceImpl implements PublishersService {

	@Autowired
    PublishersMapper publishersMapper;
 
    /**
	 * add
	 * @param params
	 * @return
	 */
    public void add(Map<String, Object> params) {
    	params.put("id", System.currentTimeMillis());
    	params.put("create_time", new Date());
		publishersMapper.add(params);
	}
 

	/**
	 * Query paging data
	 * @param params
	 * @return
	 */
    public Map<String, Object> queryList(Map<String, Object> params) {
		params.put("page",
				(Integer.valueOf(params.get("page").toString()) - 1) * Integer.valueOf(params.get("limit").toString()));
		List<Map<String, Object>> list = publishersMapper.queryList(params);
		int count = publishersMapper.queryCount(params);
		params = new HashMap<String, Object>();
		params.put("list", list);
		params.put("count", count);
		return params;
	}
	

	/**
	 * ID query
	 * @param id
	 * @return
	 */
	public Map<String, Object> queryDetail(String id) {
		
		Map<String, Object> result = publishersMapper.queryDetail(id);
		return result;
	}

	/**
	 * update
	 * @param params
	 * @return
	 */
	public void update(Map<String, Object> params) {
		params.put("update_time", new Date());
		publishersMapper.update(params);
	}

	/**
	 * delete
	 * @param id
	 * @return
	 */
	public void delete(String id) {
		 
		publishersMapper.delete(id);
	}

}
