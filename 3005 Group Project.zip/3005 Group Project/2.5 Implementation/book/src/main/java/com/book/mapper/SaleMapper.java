package com.book.mapper;

import java.util.List;
import java.util.Map;

/**
 * 
 * @author
 * @since
 */
public interface SaleMapper {

	/**
	 * add
	 * @param params
	 * @return
	 */
	void add(Map<String, Object> params);

	/**
	 * Query paging data
	 * @param params
	 * @return
	 */
	List<Map<String, Object>> queryList(Map<String, Object> params);

	int queryCount(Map<String, Object> params);

	/**
	 * ID Query Details
	 * @param id
	 * @return
	 */
	Map<String, Object> queryDetail(String id);

	/**
	 * update
	 * @param params
	 * @return
	 */
	void update(Map<String, Object> params);

	/**
	 * delete
	 * @param id
	 * @return
	 */
	void delete(String id);

}
