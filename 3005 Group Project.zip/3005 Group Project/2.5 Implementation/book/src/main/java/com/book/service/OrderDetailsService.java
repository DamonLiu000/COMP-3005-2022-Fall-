package com.book.service;

import java.util.Map;


/**
 * 
 * @author
 * @since
 */
public interface OrderDetailsService{
 
 	/**
	 * add
	 * @param params
	 * @return
	 */
	void add(Map<String, Object> params);

	 /**
	 * update
	 * @param params
	 * @return
	 */
	void update(Map<String, Object> params);
	
	/**
	 * delete
	 * @param id
	 * @return
	 */
	void delete(String id);

	/**
	 * Query paging data
	 * @param params
	 * @return
	 */
	Map<String, Object> queryList(Map<String, Object> params);

	 /**
	 * ID query
	 * @param id
	 * @return
	 */
	Map<String, Object> queryDetail(String id);
}
