package com.book.service.impl;

import com.book.mapper.WarehouseMapper;
import com.book.service.WarehouseService;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author
 * @since
 */
@Service
public class WarehouseServiceImpl implements WarehouseService {

	@Autowired
    WarehouseMapper warehouseMapper;
 
    /**
	 * add
	 * @param params
	 * @return
	 */
    public void add(Map<String, Object> params) {
    	params.put("id", System.currentTimeMillis());
		warehouseMapper.add(params);
	}
 

	/**
	 * Query paging data
	 * @param params
	 * @return
	 */
    public Map<String, Object> queryList(Map<String, Object> params) {
		params.put("page",
				(Integer.valueOf(params.get("page").toString()) - 1) * Integer.valueOf(params.get("limit").toString()));
		List<Map<String, Object>> list = warehouseMapper.queryList(params);
		int count = warehouseMapper.queryCount(params);
		params = new HashMap<String, Object>();
		params.put("list", list);
		params.put("count", count);
		return params;
	}
	

	/**
	 * ID Query Details
	 * @param id
	 * @return
	 */
	public Map<String, Object> queryDetail(String id) {
		
		Map<String, Object> result = warehouseMapper.queryDetail(id);
		return result;
	}

	/**
	 * update
	 * @param params
	 * @return
	 */
	public void update(Map<String, Object> params) {
		 
		warehouseMapper.update(params);
	}

	/**
	 * delete
	 * @param id
	 * @return
	 */
	public void delete(String id) {
		 
		warehouseMapper.delete(id);
	}

}
