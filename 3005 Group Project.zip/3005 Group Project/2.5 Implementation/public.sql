/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : PostgreSQL
 Source Server Version : 100021
 Source Host           : localhost:5432
 Source Catalog        : postgres
 Source Schema         : public

 Target Server Type    : PostgreSQL
 Target Server Version : 100021
 File Encoding         : 65001

 Date: 04/12/2022 23:31:43
*/


-- ----------------------------
-- Table structure for tb_book
-- ----------------------------
DROP TABLE IF EXISTS "public"."tb_book";
CREATE TABLE "public"."tb_book" (
  "id" varchar(50) COLLATE "pg_catalog"."default" NOT NULL,
  "book_name" varchar(100) COLLATE "pg_catalog"."default",
  "author_name" varchar(50) COLLATE "pg_catalog"."default",
  "isbn" varchar(50) COLLATE "pg_catalog"."default",
  "genre" varchar(100) COLLATE "pg_catalog"."default",
  "quantity" varchar(32) COLLATE "pg_catalog"."default",
  "publisher_id" varchar(50) COLLATE "pg_catalog"."default",
  "pages_number" varchar(32) COLLATE "pg_catalog"."default",
  "price" varchar(10) COLLATE "pg_catalog"."default",
  "bookstore_id" varchar(50) COLLATE "pg_catalog"."default",
  "warehouse_id" varchar(50) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of tb_book
-- ----------------------------
INSERT INTO "public"."tb_book" VALUES ('1670138462572', '1', '1', '1', '1', '1', '1670136207633', '1', '1', '1670087715846', '1670137913968');

-- ----------------------------
-- Table structure for tb_bookstore
-- ----------------------------
DROP TABLE IF EXISTS "public"."tb_bookstore";
CREATE TABLE "public"."tb_bookstore" (
  "id" varchar(50) COLLATE "pg_catalog"."default" NOT NULL,
  "account_number" varchar(20) COLLATE "pg_catalog"."default",
  "password" varchar(20) COLLATE "pg_catalog"."default",
  "name" varchar(20) COLLATE "pg_catalog"."default",
  "address" varchar(100) COLLATE "pg_catalog"."default",
  "create_time" date
)
;

-- ----------------------------
-- Records of tb_bookstore
-- ----------------------------
INSERT INTO "public"."tb_bookstore" VALUES ('1670087715846', '1001', '1001', '1001', '1001', '2022-12-04');

-- ----------------------------
-- Table structure for tb_checkout_basket
-- ----------------------------
DROP TABLE IF EXISTS "public"."tb_checkout_basket";
CREATE TABLE "public"."tb_checkout_basket" (
  "id" varchar(50) COLLATE "pg_catalog"."default" NOT NULL,
  "user_id" varchar(50) COLLATE "pg_catalog"."default",
  "book_id" varchar(50) COLLATE "pg_catalog"."default",
  "create_time" timestamp(0),
  "num" varchar(5) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of tb_checkout_basket
-- ----------------------------

-- ----------------------------
-- Table structure for tb_order
-- ----------------------------
DROP TABLE IF EXISTS "public"."tb_order";
CREATE TABLE "public"."tb_order" (
  "id" varchar(50) COLLATE "pg_catalog"."default" NOT NULL,
  "order_no" varchar(50) COLLATE "pg_catalog"."default",
  "total_price" numeric(10,2),
  "bookstore_id" varchar(50) COLLATE "pg_catalog"."default",
  "create_time" timestamp(0),
  "update_time" timestamp(0),
  "user_id" varchar(50) COLLATE "pg_catalog"."default",
  "state" char(2) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of tb_order
-- ----------------------------
INSERT INTO "public"."tb_order" VALUES ('1670158264378', '1670158264378', 12.00, '1670087715846', '2022-12-04 20:51:04', NULL, '1670065227352', '1 ');
INSERT INTO "public"."tb_order" VALUES ('1670158594622', '1670158594622', 144.00, '1670087715846', '2022-12-04 20:56:35', NULL, '1670065227352', '1 ');
INSERT INTO "public"."tb_order" VALUES ('1670158704728', '1670158704728', 144.00, '1670087715846', '2022-12-04 20:58:25', NULL, '1670065227352', '1 ');

-- ----------------------------
-- Table structure for tb_order_details
-- ----------------------------
DROP TABLE IF EXISTS "public"."tb_order_details";
CREATE TABLE "public"."tb_order_details" (
  "id" varchar(50) COLLATE "pg_catalog"."default" NOT NULL,
  "order_id" varchar(50) COLLATE "pg_catalog"."default",
  "book_id" varchar(50) COLLATE "pg_catalog"."default",
  "quantity" varchar(16) COLLATE "pg_catalog"."default",
  "price" varchar(10) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of tb_order_details
-- ----------------------------
INSERT INTO "public"."tb_order_details" VALUES ('1670158264393', '1670158264378', '1670138462572', '12', '12');
INSERT INTO "public"."tb_order_details" VALUES ('1670158594642', '1670158594622', '1670138462572', '12', '144');
INSERT INTO "public"."tb_order_details" VALUES ('1670158704743', '1670158704728', '1670138462572', '12', '144');

-- ----------------------------
-- Table structure for tb_publishers
-- ----------------------------
DROP TABLE IF EXISTS "public"."tb_publishers";
CREATE TABLE "public"."tb_publishers" (
  "id" varchar(50) COLLATE "pg_catalog"."default" NOT NULL,
  "name" varchar(100) COLLATE "pg_catalog"."default",
  "address" varchar(100) COLLATE "pg_catalog"."default",
  "email_address" varchar(20) COLLATE "pg_catalog"."default",
  "phone_number" varchar(20) COLLATE "pg_catalog"."default",
  "banking_account" varchar(20) COLLATE "pg_catalog"."default",
  "create_time" timestamp(0),
  "update_time" timestamp(0),
  "bookstore_id" varchar(50) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of tb_publishers
-- ----------------------------
INSERT INTO "public"."tb_publishers" VALUES ('1670136207633', '1', '1', '1', '1', '1', '2022-12-04 00:00:00', '2022-12-04 14:54:55', '1670087715846');

-- ----------------------------
-- Table structure for tb_sale
-- ----------------------------
DROP TABLE IF EXISTS "public"."tb_sale";
CREATE TABLE "public"."tb_sale" (
  "id" varchar(50) COLLATE "pg_catalog"."default" NOT NULL,
  "banking_account" varchar(20) COLLATE "pg_catalog"."default",
  "sales_volume" numeric(10,2),
  "publishers_id" varchar(50) COLLATE "pg_catalog"."default",
  "order_id" varchar(50) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of tb_sale
-- ----------------------------
INSERT INTO "public"."tb_sale" VALUES ('1670158709958', '1', 144.00, '1670136207633', '1670087715846');

-- ----------------------------
-- Table structure for tb_transport
-- ----------------------------
DROP TABLE IF EXISTS "public"."tb_transport";
CREATE TABLE "public"."tb_transport" (
  "id" varchar(50) COLLATE "pg_catalog"."default" NOT NULL,
  "order_no" varchar(50) COLLATE "pg_catalog"."default",
  "current_location" varchar(100) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of tb_transport
-- ----------------------------
INSERT INTO "public"."tb_transport" VALUES ('1670151988517', '1670149477127', '123123');

-- ----------------------------
-- Table structure for tb_user
-- ----------------------------
DROP TABLE IF EXISTS "public"."tb_user";
CREATE TABLE "public"."tb_user" (
  "id" varchar(50) COLLATE "pg_catalog"."default" NOT NULL,
  "account_number" varchar(20) COLLATE "pg_catalog"."default",
  "password" varchar(20) COLLATE "pg_catalog"."default",
  "name" varchar(50) COLLATE "pg_catalog"."default",
  "registration_time" date
)
;

-- ----------------------------
-- Records of tb_user
-- ----------------------------
INSERT INTO "public"."tb_user" VALUES ('1670065227352', '1', '1', '1', NULL);

-- ----------------------------
-- Table structure for tb_warehouse
-- ----------------------------
DROP TABLE IF EXISTS "public"."tb_warehouse";
CREATE TABLE "public"."tb_warehouse" (
  "id" varchar(50) COLLATE "pg_catalog"."default" NOT NULL,
  "name" varchar(100) COLLATE "pg_catalog"."default",
  "address" varchar(100) COLLATE "pg_catalog"."default",
  "bookstore_id" varchar(50) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of tb_warehouse
-- ----------------------------
INSERT INTO "public"."tb_warehouse" VALUES ('1670137913968', '123', '1231', '1670087715846');

-- ----------------------------
-- Primary Key structure for table tb_book
-- ----------------------------
ALTER TABLE "public"."tb_book" ADD CONSTRAINT "tb_book_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_bookstore
-- ----------------------------
ALTER TABLE "public"."tb_bookstore" ADD CONSTRAINT "tb_bookstore_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_checkout_basket
-- ----------------------------
ALTER TABLE "public"."tb_checkout_basket" ADD CONSTRAINT "tb_checkout_basket_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_order
-- ----------------------------
ALTER TABLE "public"."tb_order" ADD CONSTRAINT "tb_order_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_order_details
-- ----------------------------
ALTER TABLE "public"."tb_order_details" ADD CONSTRAINT "tb_order_details_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_publishers
-- ----------------------------
ALTER TABLE "public"."tb_publishers" ADD CONSTRAINT "tb_publishers_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_sale
-- ----------------------------
ALTER TABLE "public"."tb_sale" ADD CONSTRAINT "tb_sale_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_transport
-- ----------------------------
ALTER TABLE "public"."tb_transport" ADD CONSTRAINT "tb_transport_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_user
-- ----------------------------
ALTER TABLE "public"."tb_user" ADD CONSTRAINT "tb_user_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_warehouse
-- ----------------------------
ALTER TABLE "public"."tb_warehouse" ADD CONSTRAINT "tb_warehouse_pkey" PRIMARY KEY ("id");
